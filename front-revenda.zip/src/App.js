import { Fragment } from "react";
import { Routes, Route } from "react-router-dom";

import MenuSuperior from "./components/MenuSuperior";
import ListagemVeiculos from "./components/ListagemVeiculos";
import UserLogin from "./components/UserLogin";
import EstatisticaLikes from "./components/EstatisticaLikes";

function App() {
    return (
        <Fragment>
            <MenuSuperior />
            <Routes>
                <Route path="/" element={<ListagemVeiculos />} />
                <Route path="login" element={<UserLogin />} />
                <Route path="estatistica" element={<EstatisticaLikes />} />
            </Routes>
        </Fragment>
    );
}

export default App;
