import React from "react";

const ListagemVeiculos = () => {
    return (
        <h1>Listagem de Veículos</h1>
    );
};

export default ListagemVeiculos;