import React from "react";

const UserLogin = () => {
    return (
        <h1>Formulário de Login</h1>
    );
};

export default UserLogin;