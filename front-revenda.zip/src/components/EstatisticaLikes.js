import React from "react";

const EstatisticaLikes = () => {
    return (
        <h1>Estatística de Likes</h1>
    );
};

export default EstatisticaLikes;